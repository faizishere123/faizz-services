module.exports = {
  tokens: "7597958435:AAEBmhg5GIaGVKkyPgF1bAdClIsQOH88xdI",
  owner: "6479262268",
  port: "2002",
  ipvps: "ip vps"
};